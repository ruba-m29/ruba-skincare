import { Instagram, Mail, Phone, MapPin, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const instagramPosts = [
  'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?w=200&q=80',
  'https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?w=200&q=80',
  'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=200&q=80',
  'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=200&q=80',
];

const quickLinks = ['Shop All', 'New Arrivals', 'Best Sellers', 'Sale', 'Gift Cards'];
const helpLinks = ['Contact Us', 'FAQs', 'Shipping Info', 'Returns', 'Track Order'];

const Footer = () => {
  return (
    <footer id="footer" className="bg-card border-t border-gold/20">
      {/* Main Footer */}
      <div className="container mx-auto px-4 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-3xl font-bold gold-text-gradient">RUBA</h2>
              <p className="text-xs tracking-[0.3em] text-muted-foreground uppercase">Skincare</p>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              Where science meets luxury. Discover the secret to radiant, youthful skin with our 
              premium skincare collection.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <a 
                href="mailto:rubaskincare@gmail.com"
                className="flex items-center gap-3 text-muted-foreground hover:text-gold transition-colors"
              >
                <Mail className="h-4 w-4 text-gold" />
                rubaskincare@gmail.com
              </a>
              <a 
                href="tel:9042956746"
                className="flex items-center gap-3 text-muted-foreground hover:text-gold transition-colors"
              >
                <Phone className="h-4 w-4 text-gold" />
                9042956746
              </a>
              <div className="flex items-center gap-3 text-muted-foreground">
                <MapPin className="h-4 w-4 text-gold" />
                Chennai, India
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h3 className="font-display text-xl font-semibold text-foreground">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link}>
                  <a 
                    href="#"
                    className="text-muted-foreground hover:text-gold transition-colors duration-300 hover:pl-2"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Help */}
          <div className="space-y-6">
            <h3 className="font-display text-xl font-semibold text-foreground">Help</h3>
            <ul className="space-y-3">
              {helpLinks.map((link) => (
                <li key={link}>
                  <a 
                    href="#"
                    className="text-muted-foreground hover:text-gold transition-colors duration-300 hover:pl-2"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Instagram & Newsletter */}
          <div className="space-y-6">
            <h3 className="font-display text-xl font-semibold text-foreground">Follow Us</h3>
            
            {/* Instagram Handle */}
            <a 
              href="https://instagram.com/ruba_skincare" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
            >
              <Instagram className="h-5 w-5" />
              @ruba_skincare
            </a>

            {/* Instagram Grid */}
            <div className="grid grid-cols-2 gap-2">
              {instagramPosts.map((post, index) => (
                <a
                  key={index}
                  href="https://instagram.com/ruba_skincare"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="aspect-square rounded-lg overflow-hidden border border-gold/20 hover:border-gold/50 transition-colors"
                >
                  <img
                    src={post}
                    alt={`Instagram post ${index + 1}`}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                </a>
              ))}
            </div>

            {/* Newsletter */}
            <div className="space-y-3 pt-4">
              <p className="text-sm text-muted-foreground">Subscribe for exclusive offers</p>
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="Your email"
                  className="bg-background border-gold/30 focus:border-gold"
                />
                <Button size="icon" className="gold-gradient shrink-0">
                  <ArrowRight className="h-4 w-4 text-primary-foreground" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gold/10">
        <div className="container mx-auto px-4 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground text-center md:text-left">
              © 2024 Ruba Skincare. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-gold transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-gold transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-gold transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
