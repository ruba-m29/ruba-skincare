import { Button } from '@/components/ui/button';
import { Sun, Droplets, Feather, Shield } from 'lucide-react';

const features = [
  { icon: Sun, text: 'SPF 50+ Protection' },
  { icon: Feather, text: 'Lightweight Formula' },
  { icon: Droplets, text: 'Deep Hydrating' },
  { icon: Shield, text: 'Anti-Pollution' },
];

const NewCollection = () => {
  return (
    <section id="collection" className="py-24 bg-background relative overflow-hidden">
      {/* Background Decorations */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-gold/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Content */}
          <div className="space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 gold-gradient rounded-full">
              <span className="text-sm font-semibold text-primary-foreground">New Launch</span>
            </div>

            {/* Heading */}
            <div className="space-y-4">
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Golden Glow
                <br />
                <span className="gold-text-gradient">Sunscreen Collection</span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-lg leading-relaxed">
                Introducing our revolutionary sun protection infused with 24K gold particles 
                for the ultimate luxury skincare experience.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 p-4 bg-card rounded-xl border border-gold/20 hover:border-gold/50 transition-colors duration-300"
                >
                  <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
                    <feature.icon className="h-5 w-5 text-gold" />
                  </div>
                  <span className="font-medium text-foreground">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* Price & CTA */}
            <div className="flex flex-wrap items-center gap-6">
              <div>
                <p className="text-sm text-muted-foreground">Starting from</p>
                <p className="font-display text-4xl font-bold gold-text-gradient">₹1,299</p>
              </div>
              <Button className="gold-gradient text-primary-foreground font-semibold px-8 py-6 text-lg hover:opacity-90 transition-all duration-300 shadow-lg shadow-gold/20">
                View Collection
              </Button>
            </div>
          </div>

          {/* Right - Product Image */}
          <div className="relative">
            <div className="relative aspect-square max-w-lg mx-auto">
              {/* Main Product */}
              <div className="absolute inset-8 rounded-3xl overflow-hidden border-2 border-gold gold-border-glow bg-gradient-to-br from-card to-background">
                <img
                  src="https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600&q=80"
                  alt="Golden Glow Sunscreen"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Decorative Rings */}
              <div className="absolute inset-0 border-2 border-gold/20 rounded-full animate-pulse" />
              <div className="absolute inset-4 border border-gold/10 rounded-full" />
              
              {/* Floating Elements */}
              <div className="absolute top-4 right-4 p-3 bg-card rounded-xl border border-gold/30 shadow-lg">
                <Sun className="h-6 w-6 text-gold" />
              </div>
              <div className="absolute bottom-4 left-4 px-4 py-2 bg-gold rounded-full">
                <span className="text-sm font-semibold text-primary-foreground">Limited Edition</span>
              </div>
            </div>

            {/* Background Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gold/20 rounded-full blur-3xl" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewCollection;
