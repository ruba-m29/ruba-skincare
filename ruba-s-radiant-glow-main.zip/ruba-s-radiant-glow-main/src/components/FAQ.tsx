import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const faqs = [
  {
    question: 'What makes Ruba Skincare products unique?',
    answer: 'Our products are formulated with premium ingredients including 24K gold particles, organic botanicals, and cutting-edge skin science. Each product undergoes rigorous testing and is crafted in small batches to ensure the highest quality.',
  },
  {
    question: 'Are your products suitable for sensitive skin?',
    answer: 'Yes! All Ruba Skincare products are dermatologist-tested and suitable for all skin types, including sensitive skin. We use gentle, non-irritating formulas free from harsh chemicals, parabens, and artificial fragrances.',
  },
  {
    question: 'How long does shipping take?',
    answer: 'We offer express delivery within 3-5 business days across India. International shipping takes 7-14 business days. All orders include tracking and are carefully packaged to ensure your products arrive in perfect condition.',
  },
  {
    question: 'What is your return policy?',
    answer: 'We offer a 30-day satisfaction guarantee. If you\'re not completely happy with your purchase, simply return the unused product for a full refund. Your satisfaction is our priority.',
  },
  {
    question: 'Do you offer any subscription services?',
    answer: 'Yes! Our Glow Club membership offers exclusive discounts, early access to new launches, and monthly skincare tips from our experts. Members also receive a complimentary product with their first order.',
  },
];

const FAQ = () => {
  return (
    <section id="faq" className="py-24 bg-gradient-to-b from-background to-card">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <p className="text-gold uppercase tracking-[0.3em] text-sm font-medium">
            Have Questions?
          </p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold">
            Frequently Asked <span className="gold-text-gradient">Questions</span>
          </h2>
        </div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl mx-auto">
          <div className="p-8 md:p-12 bg-card rounded-3xl border border-gold/20 gold-border-glow">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="border border-gold/10 rounded-xl px-6 data-[state=open]:bg-gold/5 data-[state=open]:border-gold/30 transition-all duration-300"
                >
                  <AccordionTrigger className="text-left font-display text-lg font-semibold hover:text-gold hover:no-underline py-6">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-6">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>

        {/* Contact CTA */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground">
            Still have questions?{' '}
            <a href="#footer" className="text-gold hover:underline font-medium">
              Contact our team
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
