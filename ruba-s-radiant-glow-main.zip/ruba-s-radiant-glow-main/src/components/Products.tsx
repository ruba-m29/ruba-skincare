import { Button } from '@/components/ui/button';
import { ShoppingCart, Eye, Heart } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Golden Glow Moisturizer',
    category: 'Hydration',
    price: 2499,
    originalPrice: 3499,
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400&q=80',
    badge: 'Bestseller',
  },
  {
    id: 2,
    name: 'Radiance Vitamin C Serum',
    category: 'Brightening',
    price: 1999,
    originalPrice: 2799,
    image: 'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=400&q=80',
    badge: 'New',
  },
  {
    id: 3,
    name: 'Luxury SPF 50+ Sunscreen',
    category: 'Protection',
    price: 1499,
    originalPrice: 1999,
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&q=80',
    badge: 'Popular',
  },
  {
    id: 4,
    name: 'Silk Repair Shampoo',
    category: 'Hair Care',
    price: 899,
    originalPrice: 1299,
    image: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=400&q=80',
    badge: 'Sale',
  },
];

const Products = () => {
  return (
    <section id="products" className="py-24 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="space-y-4">
            <p className="text-gold uppercase tracking-[0.3em] text-sm font-medium">
              Premium Collection
            </p>
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold">
              Featured <span className="gold-text-gradient">Products</span>
            </h2>
          </div>
          <Button
            variant="outline"
            className="border-gold/50 text-gold hover:bg-gold/10 hover:border-gold w-fit"
          >
            View All Products
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product, index) => (
            <div
              key={product.id}
              className="group relative"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Image Container */}
              <div className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-card mb-4">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                
                {/* Badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 text-xs font-semibold bg-gold text-primary-foreground rounded-full">
                    {product.badge}
                  </span>
                </div>

                {/* Overlay */}
                <div className="absolute inset-0 bg-background/60 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center gap-3">
                  <Button
                    size="icon"
                    className="bg-gold text-primary-foreground hover:bg-gold-light rounded-full w-12 h-12 transform scale-0 group-hover:scale-100 transition-transform duration-300"
                    style={{ transitionDelay: '100ms' }}
                  >
                    <Eye className="h-5 w-5" />
                  </Button>
                  <Button
                    size="icon"
                    className="bg-gold text-primary-foreground hover:bg-gold-light rounded-full w-12 h-12 transform scale-0 group-hover:scale-100 transition-transform duration-300"
                    style={{ transitionDelay: '200ms' }}
                  >
                    <ShoppingCart className="h-5 w-5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    className="border-gold text-gold hover:bg-gold/10 rounded-full w-12 h-12 transform scale-0 group-hover:scale-100 transition-transform duration-300"
                    style={{ transitionDelay: '300ms' }}
                  >
                    <Heart className="h-5 w-5" />
                  </Button>
                </div>

                {/* Gradient Border on Hover */}
                <div className="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-gold/50 transition-colors duration-300" />
              </div>

              {/* Product Info */}
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground uppercase tracking-wider">
                  {product.category}
                </p>
                <h3 className="font-display text-xl font-semibold group-hover:text-gold transition-colors duration-300">
                  {product.name}
                </h3>
                <div className="flex items-center gap-3">
                  <span className="font-display text-2xl font-bold text-gold">
                    ₹{product.price.toLocaleString()}
                  </span>
                  <span className="text-muted-foreground line-through">
                    ₹{product.originalPrice.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;
