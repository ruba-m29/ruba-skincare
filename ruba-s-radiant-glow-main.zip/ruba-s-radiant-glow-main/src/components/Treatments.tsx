import { Droplets, Clock, Sparkles, Leaf } from 'lucide-react';

const treatments = [
  {
    icon: Droplets,
    title: 'Deep Hydration',
    description: 'Intensive moisture therapy that penetrates deep into skin layers for lasting hydration.',
    color: 'from-blue-500/20 to-gold/20',
  },
  {
    icon: Clock,
    title: 'Anti-Aging',
    description: 'Advanced formulas that target fine lines and wrinkles for youthful, radiant skin.',
    color: 'from-purple-500/20 to-gold/20',
  },
  {
    icon: Sparkles,
    title: 'Glow Boost',
    description: 'Brightening treatments that reveal your natural luminosity and even skin tone.',
    color: 'from-gold/30 to-amber-500/20',
  },
  {
    icon: Leaf,
    title: 'Luxury Detox',
    description: 'Premium cleansing rituals that purify and rejuvenate your skin naturally.',
    color: 'from-emerald-500/20 to-gold/20',
  },
];

const Treatments = () => {
  return (
    <section id="treatments" className="py-24 bg-gradient-to-b from-background to-card">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <p className="text-gold uppercase tracking-[0.3em] text-sm font-medium">Our Expertise</p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold">
            Best <span className="gold-text-gradient">Skincare</span> Treatments
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Experience the perfect blend of science and luxury with our signature treatments
          </p>
        </div>

        {/* Treatment Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {treatments.map((treatment, index) => (
            <div
              key={treatment.title}
              className="group relative p-8 rounded-2xl bg-card border border-gold/20 hover:border-gold/50 transition-all duration-500 hover:-translate-y-2"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {/* Gradient Background */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${treatment.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
              
              {/* Content */}
              <div className="relative z-10">
                {/* Icon */}
                <div className="w-16 h-16 rounded-xl bg-gold/10 border border-gold/30 flex items-center justify-center mb-6 group-hover:gold-border-glow transition-all duration-500">
                  <treatment.icon className="h-8 w-8 text-gold" />
                </div>

                {/* Title */}
                <h3 className="font-display text-2xl font-semibold mb-3 group-hover:text-gold transition-colors duration-300">
                  {treatment.title}
                </h3>

                {/* Description */}
                <p className="text-muted-foreground leading-relaxed">
                  {treatment.description}
                </p>

                {/* Learn More Link */}
                <div className="mt-6">
                  <span className="inline-flex items-center text-gold font-medium text-sm group-hover:underline">
                    Learn More
                    <svg
                      className="ml-2 w-4 h-4 transition-transform duration-300 group-hover:translate-x-1"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </span>
                </div>
              </div>

              {/* Decorative corner */}
              <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden rounded-tr-2xl">
                <div className="absolute top-0 right-0 w-full h-full bg-gold/5 transform rotate-45 translate-x-10 -translate-y-10" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Treatments;
