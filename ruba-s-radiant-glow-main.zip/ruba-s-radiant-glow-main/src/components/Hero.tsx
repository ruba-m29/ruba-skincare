import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';

const Hero = () => {
  const scrollToProducts = () => {
    const element = document.getElementById('products');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=1920&q=80')`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-background/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/50" />
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 right-20 w-64 h-64 bg-gold/5 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-20 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen py-24">
          {/* Left Content */}
          <div className="space-y-8 animate-fade-in-up">
            {/* Sale Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold/10 border border-gold/30 rounded-full">
              <Sparkles className="h-4 w-4 text-gold" />
              <span className="text-sm font-medium text-gold">30% OFF This Season</span>
            </div>

            {/* Main Heading */}
            <div className="space-y-4">
              <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold leading-tight">
                <span className="text-foreground">Where Science</span>
                <br />
                <span className="gold-text-gradient">Meets Luxury</span>
              </h1>
              <p className="font-display text-2xl md:text-3xl text-gold/80 italic">
                — Unveil Your Radiance
              </p>
            </div>

            {/* Description */}
            <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
              Discover our premium collection of skincare essentials, crafted with the finest 
              ingredients to reveal your skin's natural luminosity.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <Button
                onClick={scrollToProducts}
                className="group gold-gradient text-primary-foreground font-semibold px-8 py-6 text-lg hover:opacity-90 transition-all duration-300 shadow-lg shadow-gold/20"
              >
                Shop Now
                <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
              </Button>
              <Button
                variant="outline"
                onClick={() => document.getElementById('treatments')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-gold/50 text-gold hover:bg-gold/10 hover:border-gold px-8 py-6 text-lg font-semibold transition-all duration-300"
              >
                Explore
              </Button>
            </div>

            {/* Stats */}
            <div className="flex gap-8 pt-8 border-t border-gold/20">
              <div>
                <p className="font-display text-3xl font-bold gold-text-gradient">15K+</p>
                <p className="text-sm text-muted-foreground">Happy Customers</p>
              </div>
              <div>
                <p className="font-display text-3xl font-bold gold-text-gradient">50+</p>
                <p className="text-sm text-muted-foreground">Premium Products</p>
              </div>
              <div>
                <p className="font-display text-3xl font-bold gold-text-gradient">5★</p>
                <p className="text-sm text-muted-foreground">Average Rating</p>
              </div>
            </div>
          </div>

          {/* Right Content - Model Image */}
          <div className="hidden lg:block relative">
            <div className="relative w-full h-[600px] rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=800&q=80"
                alt="Luxury skincare model"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
              
              {/* Floating Card */}
              <div className="absolute bottom-8 left-8 right-8 p-6 bg-card/90 backdrop-blur-sm rounded-xl border border-gold/30 gold-border-glow">
                <p className="font-display text-lg italic text-foreground">
                  "Luxury isn't just what you wear on the outside, it's how you feel within."
                </p>
                <p className="text-gold mt-2 font-medium">— Ruba Skincare</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-gold/50 flex justify-center pt-2">
          <div className="w-1 h-2 bg-gold rounded-full" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
