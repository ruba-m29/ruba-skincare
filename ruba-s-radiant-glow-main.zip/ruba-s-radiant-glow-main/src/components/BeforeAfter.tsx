import { Button } from '@/components/ui/button';
import { Star, Quote } from 'lucide-react';

const BeforeAfter = () => {
  return (
    <section id="transformation" className="py-24 bg-gradient-to-b from-card to-background overflow-hidden">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Before/After Images */}
          <div className="relative">
            {/* Before Image */}
            <div className="relative w-[280px] h-[380px] rounded-2xl overflow-hidden border-2 border-gold/30 shadow-2xl shadow-gold/10">
              <img
                src="https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=600&q=80"
                alt="Before treatment"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-4 left-4 px-4 py-2 bg-background/90 backdrop-blur-sm rounded-lg border border-gold/30">
                <span className="text-sm font-medium text-muted-foreground">Before</span>
              </div>
            </div>

            {/* After Image - Overlapping */}
            <div className="absolute top-20 left-40 lg:left-48 w-[280px] h-[380px] rounded-2xl overflow-hidden border-2 border-gold gold-border-glow shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=600&q=80"
                alt="After treatment"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-4 right-4 px-4 py-2 gold-gradient rounded-lg">
                <span className="text-sm font-medium text-primary-foreground">After</span>
              </div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-gold/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-10 right-20 w-32 h-32 bg-gold/10 rounded-full blur-3xl" />
          </div>

          {/* Right - Content */}
          <div className="lg:pl-12 space-y-8">
            {/* Section Label */}
            <p className="text-gold uppercase tracking-[0.3em] text-sm font-medium">
              Real Results
            </p>

            {/* Heading */}
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              See the <span className="gold-text-gradient">Transformation</span>
            </h2>

            {/* Testimonial */}
            <div className="relative p-8 bg-card rounded-2xl border border-gold/20">
              <Quote className="absolute -top-4 -left-2 h-10 w-10 text-gold/30" />
              
              <p className="font-display text-xl italic text-foreground leading-relaxed mb-6">
                "After just 4 weeks of using Ruba's Golden Glow collection, my skin has never 
                looked better. The hydration is incredible, and people keep asking what my secret is!"
              </p>

              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-gold/50">
                  <img
                    src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80"
                    alt="Customer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="font-semibold text-foreground">Priya Sharma</p>
                  <p className="text-sm text-muted-foreground">Verified Customer</p>
                </div>
                <div className="ml-auto flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-gold text-gold" />
                  ))}
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center p-4 bg-card/50 rounded-xl border border-gold/10">
                <p className="font-display text-3xl font-bold gold-text-gradient">97%</p>
                <p className="text-sm text-muted-foreground mt-1">Saw Results</p>
              </div>
              <div className="text-center p-4 bg-card/50 rounded-xl border border-gold/10">
                <p className="font-display text-3xl font-bold gold-text-gradient">4 Weeks</p>
                <p className="text-sm text-muted-foreground mt-1">Avg. Time</p>
              </div>
              <div className="text-center p-4 bg-card/50 rounded-xl border border-gold/10">
                <p className="font-display text-3xl font-bold gold-text-gradient">100%</p>
                <p className="text-sm text-muted-foreground mt-1">Natural</p>
              </div>
            </div>

            {/* CTA */}
            <Button className="gold-gradient text-primary-foreground font-semibold px-8 py-6 text-lg hover:opacity-90 transition-all duration-300 shadow-lg shadow-gold/20">
              Shop Now & Transform
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BeforeAfter;
